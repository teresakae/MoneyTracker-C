/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Config;
import java.sql.Connection;

/**
 *
 * @author Joshua
 */
public class TestKoneksi {
    public static void main(String[] args) {
        Connection connection = Koneksi.getConnection();
        if (connection != null) {
            System.out.println("Koneksi ke database berhasil!");
        } else {
            System.out.println("Koneksi ke database gagal.");
        }
    }
}
